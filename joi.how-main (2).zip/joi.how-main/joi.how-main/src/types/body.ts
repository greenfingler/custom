export enum PlayerBody {
  penis = 'penis',
  vagina = 'vagina',
  neuter = 'neuter',
}

export const PlayerBodyLabels: Record<PlayerBody, string> = {
  penis: 'Cock',
  vagina: 'Pussy',
  neuter: 'Neuter',
};

export const PlayerBodyDescriptions: Record<PlayerBody, string> = {
  penis: 'You have a cock',
  vagina: 'You have a pussy',
  neuter: 'You have neither',
};
