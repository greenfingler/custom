export function round(number: number): number {
  return Math.round(number * 100) / 100;
}
