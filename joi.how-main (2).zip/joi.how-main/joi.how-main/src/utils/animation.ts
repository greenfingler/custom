export const defaultTransition = {
  duration: 0.4,
  ease: [0.23, 1, 0.32, 1],
  type: 'spring',
};
