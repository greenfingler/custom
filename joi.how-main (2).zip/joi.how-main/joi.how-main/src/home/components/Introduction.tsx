import { ContentSection } from '../../common';

export const Introduction = () => {
  return (
    <ContentSection>
      <p>
        Select your settings, and this app will guide ya&apos; thru a jack-off
        session. You can adjust most of the aspects of the game, as well as
        select some porn to help with &quot;motivation&quot;. It&apos;s all
        pulled from <a href='https://e621.net'>e621.net</a>.{' '}
        <strong>You are responsible for what you choose to look at.</strong>
      </p>
    </ContentSection>
  );
};
