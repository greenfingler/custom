## 2.6.0 - 2025-08-29

### Added

- Local videos

### Fixed

- Local images
- Secure websockets

## 2.5.0 - 2025-08-27

### Added

- option for static image duration

### Changed

- updated ui

## 2.4.1 - 2024-10-10

### Added

- Vibrator Server settings

## 2.4.0 - 2024-09-29

### Added

- local image support
- intensity progress bar

## 2.3.2 - 2024-06-08

### Fixed

- video preload
- search min score of 0
- fixed pacing percentage display

## 2.3.1 - 2024-05-19

### Fixed

- event descriptions

## 2.3.0 - 2024-05-19

### Added

- new pace curve options

### Fixed

- event descriptions

## 2.2.0 - 2024-05-13

### Added

- images are less repetitive
- images should load faster

## 2.1.0 - 2024-05-13

### Added

- pwa manifest

### Fixed

- hypno change breaking game board
- sliders on firefox
- default session duration

## 2.0.2 - 2024-05-13

### Fixed

- climax event not triggering if edge not enabled

## 2.0.1 - 2024-05-13

### Fixed

- tag search

## 2.0.0 - 2024-05-13

### Added

- login credentials
- blacklist
- optional warm up
- video support
- fullscreen button
- age warning dialog

### Fixed

- min score filtering
- vibrator integration
- game message variables

### Changed

- app design
- image managment
- removed skip and open image buttons
- udpated readme information
- settings export as file

### Added

## 1.6.0 - 2022-04-15

### Added

- New gender + genital options for text in game (from InuT-Tan <3)

## 1.5.3 - 2022-02-26

### Added

- walltaker.joi.how support

### Fixed

- Updated greeter link

## 1.5.2 - 2021-02-21

- Added an outbound link to pawflix.net since I like it so much <3

## 1.5.1 - 2021-02-09

- Raised max stroke pace to 10s/sec
- Tweaked intensity a bit
- Small bug with minimum duration

## 1.5.0 - 2021-02-07

### Added

- "Too Close" button to gameboard, allowing play to continue if you're too close to the edge to keep stroking.
- subtle animation to porn based on intensity, more to come!

### Fixed

- Tiny bug fixes and UI clarifications

### Changed

- Hypno text is now tied to intensity. (Thanks for the suggestion, Naskue!)
- Porn change cycle is now tied to intensity. (Thanks for the suggestion, Naskue!)

## 1.4.2 - 2020-12-24

### Added

- score filtering to porn settings (Suggested by Lurid)

## 1.4.1 - 2020-11-03

### Added

- New buttplug integration! We now connect via WebBluetooth to the device directly. This is much more stable than the old version, and compatible with the Lovesense Edge, amoung others. (Thanks for bringing this up NotUncommon on e621!)

### Fixed

- Bugs

### Changed

- Lowered volume on guide sounds

## 1.4.0 - 2020-05-31

### Added

- Cookie consent notice, with opt-in

## 1.3.2 - 2020-05-31

### Changed

- Copy changes

## 1.3.1 - 2020-05-31

### Fixed

- analytics

### Changed

- Copy changes

## 1.3.0 - 2020-05-24

### Added

- support for Hush butt plugs (Thanks @Fauxil)

### Fixed

- small bugs

## 1.2.3 - 2020-03-05

### Added

- support for the new E621 API

## 1.2.2 - 2020-03-01

### Added

- new "pause" event
- an option to use high res images off of E621, suggested by Zermelane on e621

### Changed

- Gifs are only animated when previewing them, rather than on the thumbnail. (Still works in-game of course!)

## 1.2.1 - 2020-02-21

### Added

- A femdom list, requested by /u/L4texP3t on reddit

### Changed

- Better description on cum event, suggested by CrocoGator on e621

## 1.2.0 - 2020-02-14

### Added

- new cum tweaks, for ejaculation and ruining probabilities

### Changed

- Tweaked some of the event probabilities

## 1.1.1 - 2019-12-25

### Added

- New lick up pre task
- Saving last session to LocalStorage for easy pick-up

### Fixed

- bugs bugs bugs

### Changed

- Better accessibility and keyboard navigation
- Cleaner looking release notes component

## 1.1.0 - 2019-12-18

### Added

- new steepness option for pace
- New hypno mode for good boys
- export/import settings from others using a shareable code

### Fixed

- some mobile styling bugs

### Changed

- Much better intensity mapping (thanks Fauxil)

## 1.0.2 - 2019-12-13

### Added

- Now you can see change logs on the client!

## 1.0.1 - 2019-12-13

### Fixed

- Just a small release for syncing up tags

## 1.0.0 - 2019-12-13

### Added

- new logo
- post number selector

### Fixed

- some weird styles

### Changed

- Renamed to JOI.how!!! 🍆
